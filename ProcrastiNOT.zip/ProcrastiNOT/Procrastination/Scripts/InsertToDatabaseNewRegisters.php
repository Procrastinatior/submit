New record inserted successfully!
<h1>Proceed to Login In</h1>
<h2><a href = "login.php">Log In</a></h2>