<?php
include "connectDB.php";

$title = $_POST['taskTitle'];

echo $title;



?>
